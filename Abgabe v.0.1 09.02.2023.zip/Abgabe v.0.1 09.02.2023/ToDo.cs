﻿namespace Abgabe;

public class ToDo
{
    static string toDo1 = null;
    static string toDo2 = null;
    static string toDo3 = null;
    static string toDo4 = null;
    static string toDo5 = null;

    static bool done1 = false;
    static bool done2 = false;
    static bool done3 = false;
    static bool done4 = false;
    static bool done5 = false;
    
    public static void ToDoHub()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Green;
            string c = "Willkommen im Todo-Hub";
            Console.SetCursorPosition((Console.WindowWidth - c.Length) / 2, Console.CursorTop);
            Console.WriteLine(c);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine();
            Console.WriteLine();

            string d = "Bitte wählen Sie eine aktion aus:";
            Console.SetCursorPosition((Console.WindowWidth - d.Length) / 2, Console.CursorTop);
            Console.WriteLine(d);

            Console.WriteLine();

            Console.WriteLine("[1] \tNeues Todo anlegen (max. 5)");
            Console.WriteLine("[2] \tÜbersicht aller ToDo's");//to delete please select a number and press yes in the overview
            Console.WriteLine("[3] \tZurück ins Hub");
            string choice = Console.ReadLine();

            if (choice == "1")
            {
                NewTodo();
            }
            else if (choice == "2")
            {
                OverviewToDo();
            }
            else if (choice == "3")
            {
                Program.LoadingScreen();
                HubMain.Hub();
            }
            else
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ungültige Eingabe, Sie werden zum Hub zurückgeleitet.");
                Console.ForegroundColor = ConsoleColor.White;
                System.Threading.Thread.Sleep(2000);
                HubMain.Hub();
            }
        }
    public static void NewTodo()
        {
          
            Program.LoadingScreen();

            Console.ForegroundColor = ConsoleColor.Green;
            string c = "Bitte geben Sie den Inhalt Ihres Todo's ein";
            Console.SetCursorPosition((Console.WindowWidth - c.Length) / 2, Console.CursorTop);
            Console.WriteLine(c);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine();

            if (toDo1 == null)
            {
                toDo1 = Console.ReadLine();
                done1 = false;
                ToDoSuccessful();
            }
            else if (toDo2 == null)
            {
                toDo2 = Console.ReadLine();
                done2 = false;
                ToDoSuccessful();

            }
            else if (toDo3 == null)
            {
                toDo3 = Console.ReadLine();
                done3 = false;
                ToDoSuccessful();
            }
            else if (toDo4 == null)
            {
                toDo4 = Console.ReadLine();
                done4 = false;
                ToDoSuccessful();
            }
            else if (toDo5 == null)
            {
                toDo5 = Console.ReadLine();
                done5 = false;
                ToDoSuccessful();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Es wurden Bereits 5 Todo's angelegt. Bitte Löschen Sie ein bestehendes ToDo in der ToDo-Übersicht");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Sie werden zurück ins Todo-Hub geleitet");
                System.Threading.Thread.Sleep(4000);
                ToDoHub();

            }

            ToDoHub();
        }
    private static void OverviewToDo()
        {
            Program.LoadingScreen();

            Console.ForegroundColor = ConsoleColor.Green;
            string c = "Willkommen in der ToDo-Übersicht";
            Console.SetCursorPosition((Console.WindowWidth - c.Length) / 2, Console.CursorTop);
            Console.WriteLine(c);
            Console.ForegroundColor = ConsoleColor.White;

            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine("Hier ist die übersicht Ihrer ToDo's.");
            Console.WriteLine("Um ein Todo zu Bearbeiten bitte geben Sie die zugehörige Nummer des ToDo's ein.");
            Console.WriteLine("Um ein zurück ins ToDo-Hub zu kommen drücken Sie die [6]");

            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine();

            //Übersicht der ToDos
            switch (done1)
            {
                case false:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("[1]" + toDo1);
                    break;
                case true:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[1]");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(toDo1);
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
            switch (done2)
            {
                case false:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("[2]" + toDo2);
                    break;
                case true:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[2]");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(toDo2);
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }           
            switch (done3)
            {
                case false:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("[3]" + toDo3);
                    break;
                case true:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[3]");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(toDo3);
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
            switch (done4)
            {
                case false:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("[4]" + toDo4);
                    break;
                case true:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[4]");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(toDo4);
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }
            switch (done5)
            {
                case false:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("[5]" + toDo5);
                    break;
                case true:
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.Write("[5]");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine(toDo5);
                    Console.ForegroundColor = ConsoleColor.White;
                    break;
            }

            Console.WriteLine();

            Console.WriteLine("[6]");

            string choice = Console.ReadLine();

            if (choice == "1")
            {
                if (toDo1 == null)
                {
                    Console.WriteLine("Bitte weisen sie dieser Position ein ToDo zu um Sie zu beartbeiten");
                }
                else
                {
                    Console.WriteLine("Wollen Sie das ToDo als abgeschlossen makieren, so drücken Sie Die [1].");
                    Console.WriteLine("Wollen Sie das ToDo Löschen, so drücken Sie Die [2].");

                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        done1 = true;
                        Console.Clear();
                        Console.WriteLine("Erfolg! Sie werden zurück ins Todo-Hub geleitet.");
                        System.Threading.Thread.Sleep(1500);
                        Program.LoadingScreen();
                        ToDoHub();
                    }
                    else if (input == "2")
                    {
                        toDo1 = null;
                        Program.LoadingScreen();
                        Console.WriteLine("ToDo 1 wurde erfolgreicht gelöscht, Sie werden ins ToDo-Hub zurückgeleitet");
                        System.Threading.Thread.Sleep(2000);
                        ToDoHub();
                    }
                    else
                    {
                        ToDoInputUnsuccessful();
                    }
                }
            }
            if (choice == "2")
            {
                if (toDo2 == null)
                {
                    Console.WriteLine("Bitte weisen sie dieser Position ein ToDo zu um Sie zu beartbeiten");
                }
                else
                {
                    Console.WriteLine("Wollen Sie das ToDo als abgeschlossen makieren, so drücken Sie Die [1].");
                    Console.WriteLine("Wollen Sie das ToDo Löschen, so drücken Sie Die [2].");

                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        done2 = true;
                        Console.Clear();
                        Console.WriteLine("Erfolg! Sie werden zurück ins Todo-Hub geleitet.");
                        System.Threading.Thread.Sleep(1500);
                        Program.LoadingScreen();
                        ToDoHub();
                    }
                    else if (input == "2")
                    {
                        toDo2 = null;
                        Program.LoadingScreen();
                        Console.WriteLine("ToDo 2 wurde erfolgreicht gelöscht, Sie werden ins ToDo-Hub zurückgeleitet");
                        System.Threading.Thread.Sleep(2000);
                        ToDoHub();
                    }
                    else
                    {
                        ToDoInputUnsuccessful();
                    }
                }
            }
            if (choice == "3")
            {
                if (toDo3 == null)
                {
                    Console.WriteLine("Bitte weisen sie dieser Position ein ToDo zu um Sie zu beartbeiten");
                }
                else
                {
                    Console.WriteLine("Wollen Sie das ToDo als abgeschlossen makieren, so drücken Sie Die [1].");
                    Console.WriteLine("Wollen Sie das ToDo Löschen, so drücken Sie Die [2].");

                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        done3 = true;
                        Console.Clear();
                        Console.WriteLine("Erfolg! Sie werden zurück ins Todo-Hub geleitet.");
                        System.Threading.Thread.Sleep(1500);
                        Program.LoadingScreen();
                        ToDoHub();
                    }
                    else if (input == "2")
                    {
                        toDo3 = null;
                        Program.LoadingScreen();
                        Console.WriteLine("ToDo 3 wurde erfolgreicht gelöscht, Sie werden ins ToDo-Hub zurückgeleitet");
                        System.Threading.Thread.Sleep(2000);
                        ToDoHub();
                    }
                    else
                    {
                        ToDoInputUnsuccessful();
                    }
                }
            }
            if (choice == "4")
            {
                if (toDo4 == null)
                {
                    Console.WriteLine("Bitte weisen sie dieser Position ein ToDo zu um Sie zu beartbeiten");
                }
                else
                {
                    Console.WriteLine("Wollen Sie das ToDo als abgeschlossen makieren, so drücken Sie Die [1].");
                    Console.WriteLine("Wollen Sie das ToDo Löschen, so drücken Sie Die [2].");

                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        done4 = true;
                        Console.Clear();
                        Console.WriteLine("Erfolg! Sie werden zurück ins Todo-Hub geleitet.");
                        System.Threading.Thread.Sleep(1500); Program.LoadingScreen();
                        ToDoHub(); 
                    }
                    else if (input == "2")
                    {
                        toDo4 = null;
                        Program.LoadingScreen();
                        Console.WriteLine("ToDo 4 wurde erfolgreicht gelöscht, Sie werden ins ToDo-Hub zurückgeleitet");
                        System.Threading.Thread.Sleep(2000);
                        ToDoHub();
                    }
                    else
                    {
                        ToDoInputUnsuccessful();
                    }
                }
            }
            if (choice == "5")
            {
                if (toDo5 == null)
                {
                    Console.WriteLine("Bitte weisen sie dieser Position ein ToDo zu um Sie zu beartbeiten");
                }
                else
                {
                    Console.WriteLine("Wollen Sie das ToDo als abgeschlossen makieren, so drücken Sie Die [1].");
                    Console.WriteLine("Wollen Sie das ToDo Löschen, so drücken Sie Die [2].");

                    string input = Console.ReadLine();

                    if (input == "1")
                    {
                        done5 = true;
                        Console.Clear();
                        Console.WriteLine("Erfolg! Sie werden zurück ins Todo-Hub geleitet.");
                        System.Threading.Thread.Sleep(1500);
                        Program.LoadingScreen();
                        ToDoHub();
                    }
                    else if (input == "2")
                    {
                        toDo5 = null;
                        Program.LoadingScreen();
                        Console.WriteLine("ToDo 5 wurde erfolgreicht gelöscht, Sie werden ins ToDo-Hub zurückgeleitet");
                        System.Threading.Thread.Sleep(2000);
                        ToDoHub();
                    }
                    else
                    {
                        ToDoInputUnsuccessful();
                    }
                }
            }
            if (choice == "6")
            {
                Program.LoadingScreen();
                ToDoHub();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ungültige Eingabe.");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Sie werden zurück ins Todo-Hub geleitet");
                System.Threading.Thread.Sleep(1500);
                ToDoHub();
            }

          
        }
    private static void ToDoSuccessful()
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Ihr ToDo wurde erfolgreich Angelegt, Sie werden zurück ins ToDo-Hub geleitet.");
            Console.ForegroundColor = ConsoleColor.White;
            System.Threading.Thread.Sleep(1500);
            ToDoHub();
        }
    private static void ToDoInputUnsuccessful()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Ungültige Eingabe, Sie werden zum ToDo-Hub zurückgeleitet.");
            Console.ForegroundColor = ConsoleColor.White;
            System.Threading.Thread.Sleep(2000);
            ToDoHub();
        }
}