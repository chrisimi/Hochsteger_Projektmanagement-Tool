﻿/*Das Projekt soll mittels OOP ergänzt werden. Hierzu meine Empfehlung:
-Neues Projekt starten und alte Logik in OOP einpacken
-Methoden und auch Klassen sollen sinnhaft herunter gebrochen werden
-Main Methode soll nur mehr die Objektinstanzierung und Methodenaufrufe beinhalten
-Es soll in der Klasse Programm keine Logik mehr vorhanden sein
-Vererbung, abstrakte Klassen....
*/
using System;

namespace Abgabe
{
    public record FragenWrapper( //encapsulation
        int Frage1,
        int Frage2,
        int Frage3,
        int Frage4,
        int Frage5);

    public class Program
    {
        public static bool activate = false; 
        public static FragenWrapper? _fragen;
      
        
        public static void Main(string[] args)
        {

            Console.ForegroundColor = ConsoleColor.Blue;

            string s = "*****Willkommen beim Projektplaner*****";
            Console.SetCursorPosition((Console.WindowWidth - s.Length) / 2, Console.CursorTop);
            Console.WriteLine(s);

            Console.ForegroundColor = ConsoleColor.White;

            string a = "Bitte Erstellen Sie einen Account";
            Console.SetCursorPosition((Console.WindowWidth - a.Length) / 2, Console.CursorTop);
            Console.WriteLine(a);

            Console.WriteLine();
            Console.WriteLine();

            //get Username + password
            Console.WriteLine("Wählen Sie dafür einen angemessenen Benutzernamen: ");
            Login.username = Console.ReadLine();
            Console.WriteLine("Wählen Sie ein Passwort: "); //evt. stärke
            Login.password = Console.ReadLine();

            LoadingScreen();

            //LOGIN SYSTEM
            Login.LoginLogic();
            HubMain.Hub();

        }
        public static void Exit()
        {
            Console.Clear();
            Console.ForegroundColor = ConsoleColor.Red;

            Console.WriteLine("Programm wird geschlossen.");
            System.Threading.Thread.Sleep(400);
            Console.Clear();
            Console.WriteLine("Programm wird geschlossen..");
            System.Threading.Thread.Sleep(700);
            Console.Clear();
            Console.WriteLine("Programm wird geschlossen...");
            System.Threading.Thread.Sleep(200);
            Console.Clear();
            Console.WriteLine("Programm wird geschlossen....");
            System.Threading.Thread.Sleep(900);
            Console.Clear();
            Console.WriteLine("Programm wird geschlossen.....");
            System.Threading.Thread.Sleep(1000);
            Console.Clear();
            Console.WriteLine("Done!");
            System.Threading.Thread.Sleep(1000);
            Console.Clear();
            Console.WriteLine("Bis zum nächsten mal!");
            System.Threading.Thread.Sleep(2000);

            Environment.Exit(0);
        }
        public static void LoadingScreen()
        {
            Console.Clear();
            Console.WriteLine("...");
            System.Threading.Thread.Sleep(300);
            Console.WriteLine("..");
            Console.WriteLine(".");
            System.Threading.Thread.Sleep(800);
            Console.Clear();
        }

    }
}