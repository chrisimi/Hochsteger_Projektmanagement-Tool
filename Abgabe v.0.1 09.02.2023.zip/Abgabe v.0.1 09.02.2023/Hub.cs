﻿namespace Abgabe;

public class HubMain
{
     public static void Hub()
        {

            Console.ForegroundColor = ConsoleColor.Green;
            string b = "-----Willkommen im Hub-----";
            Console.SetCursorPosition((Console.WindowWidth - b.Length) / 2, Console.CursorTop);
            Console.WriteLine(b);
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine("Wählen Sie eine Aktion und geben sie die zugehörige Nummer in die Konsole ein.");

            Console.WriteLine("[1]\tGeben Sie die Einstufung der Projektanalyse für Ihr Projekt ab um eine vollwertige Auswertung zu bekommen.");
            if (Program.activate)
                Console.ForegroundColor = ConsoleColor.White;
            if (!Program.activate)
            {
                Console.ForegroundColor = ConsoleColor.DarkGray;
            }
            // if(_fragen is not null)
            Console.WriteLine("[2]\tSinnhaftigkeitsauswertung des eingegebenen Projekts (Um diese Funktion zu verwenden benützen Sie Funktion [1])"); Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("[3]\tTodo-Hub"); 
            Console.WriteLine("[4]\tExit");

            string aktion = Console.ReadLine();

            if (aktion == "1")
            {
                Projektanalyse.Analyse();
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Sie werden zurück zum Hub geleitet...");

                Hub();
            }
            else if (aktion == "2")
            {
                if (!Program.activate)
                {
                    AuswertungsAlgorithmus.SinnhaftigkeitGrey();
                }
                if (Program._fragen is not null)
                {
                    AuswertungsAlgorithmus.Algorithmus();
                }
            }
            else if (aktion == "3")
            {
                ToDo.ToDoHub();
            }
            else if (aktion == "4")
            {
                Program.Exit();
            }
            else
            {
                Console.Clear();
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("Ungültige Eingabe, Sie werden zum Hub zurückgeleitet.");
                Console.ForegroundColor = ConsoleColor.White;
                System.Threading.Thread.Sleep(2000);
                Hub();
            }
            Console.ReadLine();
        }
}