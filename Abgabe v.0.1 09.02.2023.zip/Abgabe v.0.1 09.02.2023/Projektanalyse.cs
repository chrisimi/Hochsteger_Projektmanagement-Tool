﻿namespace Abgabe;

public class Projektanalyse
{
    public static void Analyse()
    {
            int frage1;
            int frage2;
            int frage3;
            int frage4;
            int frage5; 

            Program.LoadingScreen();
            //Einlesen der Fragen
            Console.ForegroundColor = ConsoleColor.Green;
            string c = "Willkommen bei der Sinnhaftigkeitsauswertung";
            Console.SetCursorPosition((Console.WindowWidth - c.Length) / 2, Console.CursorTop);
            Console.WriteLine(c);
            Console.ForegroundColor = ConsoleColor.White;

            Console.WriteLine();

            Console.WriteLine("Bitte Beantworten Sie folgende Fragen (benützen Sie die Zahlen 1-3):");
            System.Threading.Thread.Sleep(3000);
            Console.Clear();

            //Frage 1
            string d = "Wie würden Sie die Komplexität Ihres Projektes einschätzen?";
            Console.SetCursorPosition((Console.WindowWidth - d.Length) / 2, Console.CursorTop);
            Console.WriteLine(d);
            Console.WriteLine();
            Console.WriteLine("Wählen Sie aus zwischen: ");
            Console.WriteLine("[1]\t'Niedrig'");
            Console.WriteLine("[2]\t'Mittel'");
            Console.WriteLine("[3]\t'Hoch'");
            frage1 = Convert.ToInt32(Console.ReadLine());

            Console.Clear();
            //Frage 2
            string e = "Wie würden Sie die Neuartigkeit Ihres Projektes einschätzen?";
            Console.SetCursorPosition((Console.WindowWidth - e.Length) / 2, Console.CursorTop);
            Console.WriteLine(e);
            Console.WriteLine();
            Console.WriteLine("Wählen Sie aus zwischen: ");
            Console.WriteLine("[1]\t'Niedrig'");
            Console.WriteLine("[2]\t'Mittel'");
            Console.WriteLine("[3]\t'Hoch'");
            frage2 = Convert.ToInt32(Console.ReadLine());

            Console.Clear();
            //Frage 3
            string f = "Wie würden Sie das Risiko Ihres Projektes einschätzen?";
            Console.SetCursorPosition((Console.WindowWidth - f.Length) / 2, Console.CursorTop);
            Console.WriteLine(f);
            Console.WriteLine();
            Console.WriteLine("Wählen Sie aus zwischen: ");
            Console.WriteLine("[1]\t'Niedrig'");
            Console.WriteLine("[2]\t'Mittel'");
            Console.WriteLine("[3]\t'Hoch'");
            frage3 = Convert.ToInt32(Console.ReadLine());

            Console.Clear();
            //Frage 4
            string g = "Wie würden Sie die Strategische Bedeutsamkeit Ihres Projektes einschätzen?";
            Console.SetCursorPosition((Console.WindowWidth - g.Length) / 2, Console.CursorTop);
            Console.WriteLine(g);
            Console.WriteLine();
            Console.WriteLine("Wählen Sie aus zwischen: ");
            Console.WriteLine("[1]\t'Niedrig'");
            Console.WriteLine("[2]\t'Mittel'");
            Console.WriteLine("[3]\t'Hoch'");
            frage4 = Convert.ToInt32(Console.ReadLine());

            Console.Clear();
            //Frage 5
            string h = "Wie würden Sie die Zieldeterminiertheit Ihres Projektes einschätzen?";
            Console.SetCursorPosition((Console.WindowWidth - h.Length) / 2, Console.CursorTop);
            Console.WriteLine(h);
            Console.WriteLine();
            Console.WriteLine("Wählen Sie aus zwischen: ");
            Console.WriteLine("[1]\t'Niedrig'");
            Console.WriteLine("[2]\t'Mittel'");
            Console.WriteLine("[3]\t'Hoch'");
            frage5 = Convert.ToInt32(Console.ReadLine());

            Program.activate = true;


            /////////////////erklärung (etw. zusammenpacken um zu vereinfachen | DTO)Kebab/////////////////

            Program._fragen = new FragenWrapper(frage1, frage2, frage3, frage4, frage5);
    }
}