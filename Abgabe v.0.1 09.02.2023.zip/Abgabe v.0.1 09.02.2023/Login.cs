﻿namespace Abgabe;

public class Login
{
    internal static string username;
    internal static string password;
     public static void LoginLogic()
        {
            string username2;
            string password2;

            bool login = false;
            bool login2 = false;

            int counter = 0;

            Console.WriteLine("Please Login");

            Console.Write("Username:\t");
            while (login == false)
            {
                username2 = Console.ReadLine();
                if (username2 == username)
                {
                    login = true;
                }
                else
                {
                    counter++;
                    if (counter == 5)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("------------------------------------------------------------");
                        Console.WriteLine("Falscher Benutzer zu oft eingegeben. Sitzung wird beendet. ");
                        Console.WriteLine("------------------------------------------------------------");
                        System.Threading.Thread.Sleep(5000);
                        Environment.Exit(0);
                    }

                    Console.Clear();
                    Console.WriteLine("Falscher Username. Versuch " + counter + " von 5");
                    Console.Write("Username:\t");
                }


            }


            Console.Write("Passwort:\t");
            while (login2 == false)
            {
                password2 = Console.ReadLine();
                if (password2 == password)
                {
                    Console.Clear();
                    Console.WriteLine("Sie werden in kürze eingeloggt");
                    System.Threading.Thread.Sleep(1000);

                    login2 = true;
                }
                else
                {
                    if (counter == 5)
                    {
                        Console.Clear();
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("----------------------------------------------------------");
                        Console.WriteLine("Falsches Passwort zu oft eingegeben. Sitzung wird beendet. ");
                        Console.WriteLine("----------------------------------------------------------");
                        System.Threading.Thread.Sleep(5000);
                        Environment.Exit(0);
                    }
                    counter++;
                    Console.WriteLine("Falsches Passwort. Versuch " + counter + " von 5");
                    Console.Write("Passwort:\t");
                }

            }

            Console.WriteLine("...");
            System.Threading.Thread.Sleep(300);
            Console.WriteLine("..");
            Console.WriteLine(".");
            System.Threading.Thread.Sleep(800);
            Console.Clear();

            Console.WriteLine("You are Now Logged In. Welcome " + username + ".");
        }
}