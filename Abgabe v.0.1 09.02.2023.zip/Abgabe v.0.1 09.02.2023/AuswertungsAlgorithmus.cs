﻿namespace Abgabe;

public class AuswertungsAlgorithmus
{
     public static void Algorithmus()
        {
            if (Program._fragen!.Frage5 > 1 && Program._fragen.Frage2 > 1 && Program._fragen.Frage3 < 3 && Program._fragen.Frage4 <= 3 && Program._fragen.Frage1 <= 3)
            {
                Program.LoadingScreen();

                //ausgabe
                Console.ForegroundColor = ConsoleColor.Green;
                string g = "-----Willkommen bei der Auswertung-----";
                Console.SetCursorPosition((Console.WindowWidth - g.Length) / 2, Console.CursorTop);
                Console.WriteLine(g);
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(2000);

                Console.WriteLine("Die Ergebnisse der Auswertung Lauten wie folgt:");
                Console.WriteLine();
                Console.WriteLine();

                System.Threading.Thread.Sleep(1000);

                Console.ForegroundColor = ConsoleColor.DarkBlue;
                string h = "Vorschlag";
                Console.SetCursorPosition((Console.WindowWidth - h.Length) / 2, Console.CursorTop);
                Console.WriteLine(h);
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(500);
                Console.WriteLine();

                Console.WriteLine("Projekt/Aufgabe        \tProjekt");
                Console.WriteLine("Wann?                  \tFangen Sie so bald wie möglich an");

                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("press any key to continue");
                Console.ReadKey();

                Console.Clear();
                HubMain.Hub();

            }
            else if (Program._fragen.Frage5 <= 2 && Program._fragen.Frage1 == 3 && Program._fragen.Frage2 == 1 && Program._fragen.Frage3 == 3 && Program._fragen.Frage4 < 3)
            {
                Program.LoadingScreen();
                Console.ForegroundColor = ConsoleColor.Green;
                string g = "-----Willkommen bei der Auswertung-----";
                Console.SetCursorPosition((Console.WindowWidth - g.Length) / 2, Console.CursorTop);
                Console.WriteLine(g);
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(2000);

                Console.WriteLine("Die Ergebnisse der Auswertung Lauten wie folgt:");
                Console.WriteLine();
                Console.WriteLine();

                System.Threading.Thread.Sleep(1000);

                Console.ForegroundColor = ConsoleColor.DarkBlue;
                string h = "Vorschlag";
                Console.SetCursorPosition((Console.WindowWidth - h.Length) / 2, Console.CursorTop);
                Console.WriteLine(h);
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(500);
                Console.WriteLine();

                Console.WriteLine("Projekt/Aufgabe        \tAufgabe");
                Console.WriteLine("Wann?                  \tVerwerfen Sie das Projekt");

                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("press any key to continue");
                Console.ReadKey();

                Console.Clear();
                HubMain.Hub();
            }
            else if (Program._fragen.Frage5 <= 1 && Program._fragen.Frage2 >= 1 && Program._fragen.Frage4 > 1 && Program._fragen.Frage1 >= 1 && Program._fragen.Frage3 >= 1)
            {
                Program.LoadingScreen();

                Console.ForegroundColor = ConsoleColor.Green;
                string g = "-----Willkommen bei der Auswertung-----";
                Console.SetCursorPosition((Console.WindowWidth - g.Length) / 2, Console.CursorTop);
                Console.WriteLine(g);
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(2000);

                Console.WriteLine("Die Ergebnisse der Auswertung Lauten wie folgt:");
                Console.WriteLine();
                Console.WriteLine();

                System.Threading.Thread.Sleep(1000);

                Console.ForegroundColor = ConsoleColor.DarkBlue;
                string h = "Vorschlag";
                Console.SetCursorPosition((Console.WindowWidth - h.Length) / 2, Console.CursorTop);
                Console.WriteLine(h);
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(500);
                Console.WriteLine();

                Console.WriteLine("Projekt/Aufgabe        \tProjekt");
                Console.WriteLine("Wann?                  \tPlanen Sie das Projekt");

                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("press any key to continue");
                Console.ReadKey();

                Console.Clear();
                HubMain.Hub();
            }
            else
            {
                Program.LoadingScreen();

                Console.ForegroundColor = ConsoleColor.Green;
                string g = "-----Willkommen bei der Auswertung-----";
                Console.SetCursorPosition((Console.WindowWidth - g.Length) / 2, Console.CursorTop);
                Console.WriteLine(g);
                Console.WriteLine();
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(2000);

                Console.WriteLine("Die Ergebnisse der Auswertung Lauten wie folgt:");
                Console.WriteLine();
                Console.WriteLine();

                System.Threading.Thread.Sleep(1000);

                Console.ForegroundColor = ConsoleColor.DarkBlue;
                string h = "Vorschlag";
                Console.SetCursorPosition((Console.WindowWidth - h.Length) / 2, Console.CursorTop);
                Console.WriteLine(h);
                Console.ForegroundColor = ConsoleColor.White;

                System.Threading.Thread.Sleep(500);
                Console.WriteLine();

                Console.WriteLine("Projekt/Aufgabe        \tAufgabe");
                Console.WriteLine("Wann?                  \tVerwerfen Sie das Projekt");

                Console.WriteLine();
                Console.WriteLine();

                Console.WriteLine("press any key to continue");
                Console.ReadKey();

                Console.Clear();
                HubMain.Hub();
            }
        }
     
     public static void SinnhaftigkeitGrey()
     {
         Program.LoadingScreen();

         Console.ForegroundColor = ConsoleColor.Red;
         Console.WriteLine("Um diese Funktion zu verwenden, benützen Sie Funktion [1] im Hub");
         Console.ForegroundColor = ConsoleColor.White;
         System.Threading.Thread.Sleep(4000);
         Console.Clear();
         HubMain.Hub();
     }
}